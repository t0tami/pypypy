package org.example;

import first.task.Student;
import fourth.task.WourdCount;
import second.task.SubjectGrades;
import third.task.AdressBook;
import javax.security.auth.Subject;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        /*Student student1 = new Student("Misha", "A666");
        Student student2 = new Student("Danya", "B999");

        Student.addStudent(student1.getStudentId(),student1);
        Student.addStudent(student2.getStudentId(),student2);


        System.out.println(Student.getStudent("B999"));*/
        /*SubjectGrades.addGrade("Alina", 85);
        SubjectGrades.addGrade("Liza", 90);
        SubjectGrades.addGrade("Bob", 88);

        SubjectGrades grades = new SubjectGrades("Math");
        double average =  SubjectGrades.calculateAverage();
        System.out.println("Average grade in "+ grades.getSubject() + ": " + average);*/

        /*AdressBook adressBook = new AdressBook();
        adressBook.addContact("Nika", "535356435");
        adressBook.addContact("Dima", "9897548698");
        adressBook.addContact("Liza", "3212354863");

        System.out.println("Телефон Ники: "+ adressBook.getPhone("Nika"));
        System.out.println("Телефон Димы: "+ adressBook.getPhone("Dima"));

        adressBook.displayContacts();

        AdressBook.removeContact("Liza");
        System.out.println("После удаления Лизы");

        adressBook.displayContacts();*/

        String sentence ="Hello word! Hello everyone. Welcome to the world of Java";
        Map<String , Integer> frequency = WourdCount.countWordFrequency(sentence);

        for (Map.Entry<String, Integer> entry : frequency.entrySet()){
            System.out.println(entry.getKey() + ": "+ entry.getValue());


        }


        }
    }
