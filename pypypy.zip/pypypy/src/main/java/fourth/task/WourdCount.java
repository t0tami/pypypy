package fourth.task;

import java.util.HashMap;
import java.util.Map;

public class WourdCount {
    public static Map<String, Integer> countWordFrequency(String sentence){
        Map<String , Integer> wordCountMap = new HashMap<>();
        String[] words = sentence.toLowerCase().split("\\W+");

        for (String word : words ){
            if (!word.isEmpty()){
                wordCountMap.put(word,wordCountMap.getOrDefault(word,0)+1);
            }
        }
        return wordCountMap;
    }

}
